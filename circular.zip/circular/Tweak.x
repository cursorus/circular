#import <UIKit/UIKit.h>

struct SBIconCoordinate { long long row; long long col; };

@interface SBIconView : UIView
+ (CGSize)defaultIconSize;
@end

@interface SBIconImageView : UIView
@end

@interface SBIconListView : UIView
- (unsigned long long)iconColumnsForCurrentOrientation;
- (CGFloat)topIconInset;
@end

static BOOL gEnabled = YES;
static NSInteger gFirstRow = 4; // 4 -> 4-3-4-3, 3 -> 3-4-3-4

static void loadPrefs(void) {
    NSDictionary *p = [NSDictionary dictionaryWithContentsOfFile:@"/var/mobile/Library/Preferences/com.cursorus.circular.plist"];
    gEnabled = p[@"enabled"] ? [p[@"enabled"] boolValue] : YES;
    NSInteger f = p[@"firstRow"] ? [p[@"firstRow"] integerValue] : 4;
    gFirstRow = (f == 3) ? 3 : 4;
}

static void prefsChanged(CFNotificationCenterRef c, void *o, CFStringRef n, const void *obj, CFDictionaryRef u) {
    loadPrefs();
}

// index in linear order -> point in the staggered grid
static CGPoint circularOrigin(SBIconListView *list, unsigned long long idx) {
    NSInteger a = gFirstRow;
    NSInteger b = (a == 4) ? 3 : 4;
    NSInteger pair = idx / 7, r = idx % 7;
    NSInteger row, col, count;
    if (r < a) { row = pair * 2;     col = r;     count = a; }
    else       { row = pair * 2 + 1; col = r - a; count = b; }

    CGFloat W = list.bounds.size.width;
    CGFloat pitch = W / 4.0;                       // 80 on 5s
    CGSize isz = [%c(SBIconView) defaultIconSize]; // 60x60 on 5s
    CGFloat top = [list respondsToSelector:@selector(topIconInset)] ? [list topIconInset] : 30.0;

    CGFloat x = (W - count * pitch) / 2.0 + col * pitch + (pitch - isz.width) / 2.0;
    CGFloat y = top + row * pitch;
    return CGPointMake(x, y);
}

%hook SBIconListView

- (CGPoint)originForIconAtCoordinate:(struct SBIconCoordinate)c {
    if (!gEnabled) return %orig;
    unsigned long long cols = [self iconColumnsForCurrentOrientation];
    if (cols == 0) cols = 4;
    return circularOrigin(self, (unsigned long long)(c.row * cols + c.col));
}

- (CGPoint)originForIconAtIndex:(unsigned long long)idx {
    if (!gEnabled) return %orig;
    return circularOrigin(self, idx);
}

%end

%hook SBIconImageView

- (void)layoutSubviews {
    %orig;
    if (!gEnabled) return;
    CGFloat d = MIN(self.bounds.size.width, self.bounds.size.height);
    self.layer.cornerRadius = d / 2.0;
    self.layer.masksToBounds = YES;
}

%end

%ctor {
    loadPrefs();
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, prefsChanged,
        CFSTR("com.cursorus.circular/prefschanged"), NULL, CFNotificationSuspensionBehaviorCoalesce);
}
